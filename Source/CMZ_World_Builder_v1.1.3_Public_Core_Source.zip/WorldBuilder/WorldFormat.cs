using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Win32;

namespace CMZWorldBuilder
{
    public static class WorldFormat
    {
        private const int SaveMagic = unchecked((int)0x44535452); // "RTSD" little-endian
        private const int SaveVersion = 5;
        private const uint SaveFlags = 3; // compressed + protected
        private const int MaxProtectedPayload = 64 * 1024 * 1024;
        private static readonly object SeedSync = new object();
        private static readonly Random SeedRandom = new Random();

        public static byte[] SerializeWorldInfo(WorldInfo info)
        {
            if (info == null) throw new ArgumentNullException("info");
            if (info.Version < 1 || info.Version > WorldBuilderInfo.WorldInfoVersion)
                throw new InvalidDataException("Unsupported world.info version: " + info.Version + ".");
            if (info.CrateCount != 0 || info.DoorCount != 0 || info.SpawnerCount != 0)
                throw new InvalidOperationException("World Builder serialization only supports fresh-world metadata with no saved crate, door, or spawner records.");

            using (MemoryStream ms = new MemoryStream())
            using (BinaryWriter w = new BinaryWriter(ms, Encoding.UTF8))
            {
                w.Write(info.Version);
                w.Write(info.TerrainVersion);
                WriteDotNetString(w, info.Name ?? "");
                WriteDotNetString(w, info.OwnerGamerTag ?? "");
                WriteDotNetString(w, info.CreatorGamerTag ?? "");
                w.Write(info.CreatedTicks);
                w.Write(info.LastPlayedTicks);
                w.Write(info.Seed);
                w.Write(info.WorldID.ToByteArray());
                w.Write(info.LastX);
                w.Write(info.LastY);
                w.Write(info.LastZ);

                // CastleMiner Z serializes variable-length saved-object collections
                // in world.info. Fresh World Builder foundations intentionally start
                // with empty collections, but the version gates must still mirror the
                // game's loader exactly.
                w.Write(0); // crates: every supported world.info version
                if (info.Version > 2) w.Write(0); // doors: v3+
                if (info.Version > 3) w.Write(0); // spawners: v4+

                w.Write(info.InfiniteResource);
                WriteDotNetString(w, info.ServerMessage ?? "");
                WriteDotNetString(w, info.ServerPassword ?? "");
                if (info.Version > 4)
                {
                    w.Write(info.HellBosses);
                    w.Write(info.MaxHellBosses);
                }
                w.Flush();
                return ms.ToArray();
            }
        }

        public static WorldInfo ParseWorldInfo(byte[] data)
        {
            if (data == null) throw new ArgumentNullException("data");
            using (MemoryStream ms = new MemoryStream(data, false))
            using (BinaryReader r = new BinaryReader(ms, Encoding.UTF8))
            {
                WorldInfo info = new WorldInfo();
                info.Version = r.ReadInt32();
                if (info.Version < 1 || info.Version > WorldBuilderInfo.WorldInfoVersion)
                    throw new InvalidDataException("Unsupported world.info version: " + info.Version + ".");

                info.TerrainVersion = r.ReadInt32();
                info.Name = ReadDotNetString(r);
                info.OwnerGamerTag = ReadDotNetString(r);
                info.CreatorGamerTag = ReadDotNetString(r);
                info.CreatedTicks = r.ReadInt64();
                info.LastPlayedTicks = r.ReadInt64();
                info.Seed = r.ReadInt32();
                info.WorldID = new Guid(ReadExactly(r, 16));
                info.LastX = r.ReadSingle();
                info.LastY = r.ReadSingle();
                info.LastZ = r.ReadSingle();

                info.CrateCount = ReadWorldObjectCount(r, "crate", 44);
                for (int i = 0; i < info.CrateCount; i++) SkipCrateRecord(r);

                if (info.Version > 2)
                {
                    info.DoorCount = ReadWorldObjectCount(r, "door", 13);
                    for (int i = 0; i < info.DoorCount; i++) SkipDoorRecord(r);
                }

                if (info.Version > 3)
                {
                    info.SpawnerCount = ReadWorldObjectCount(r, "spawner", 13);
                    for (int i = 0; i < info.SpawnerCount; i++) SkipSpawnerRecord(r);
                }

                info.InfiniteResource = r.ReadBoolean();
                info.ServerMessage = ReadDotNetString(r);
                info.ServerPassword = ReadDotNetString(r);
                if (info.Version > 4)
                {
                    info.HellBosses = r.ReadInt32();
                    info.MaxHellBosses = r.ReadInt32();
                }

                // Match CastleMiner Z's loader: consume the known versioned fields and
                // do not reject harmless trailing bytes the game itself would ignore.
                return info;
            }
        }

        public static byte[] ProtectSave(byte[] rawWorldInfo, string profileId)
        {
            if (rawWorldInfo == null) throw new ArgumentNullException("rawWorldInfo");
            ValidateProfileId(profileId);

            byte[] compressed = CompressPayload(rawWorldInfo);
            byte[] encrypted = EncryptPayload(compressed, profileId);
            byte[] hash;
            using (MD5 md5 = MD5.Create()) hash = md5.ComputeHash(encrypted);

            using (MemoryStream blockStream = new MemoryStream())
            using (BinaryWriter block = new BinaryWriter(blockStream))
            {
                block.Write(hash.Length);
                block.Write(hash);
                block.Write(encrypted.Length);
                block.Write(encrypted);
                block.Flush();
                byte[] protectedBlock = blockStream.ToArray();

                using (MemoryStream outputStream = new MemoryStream())
                using (BinaryWriter output = new BinaryWriter(outputStream))
                {
                    output.Write(SaveMagic);
                    output.Write(SaveVersion);
                    output.Write(SaveFlags);
                    output.Write(protectedBlock.Length);
                    output.Write(protectedBlock);
                    output.Flush();
                    return outputStream.ToArray();
                }
            }
        }

        public static byte[] UnprotectSave(byte[] envelope, string profileId)
        {
            if (envelope == null) throw new ArgumentNullException("envelope");
            ValidateProfileId(profileId);
            using (MemoryStream ms = new MemoryStream(envelope, false))
            using (BinaryReader r = new BinaryReader(ms))
            {
                if (r.ReadInt32() != SaveMagic)
                    throw new InvalidDataException("world.info has an invalid protected-save magic value.");
                int version = r.ReadInt32();
                if (version < 3 || version > 5)
                    throw new InvalidDataException("Unsupported protected-save version: " + version + ".");
                uint flags = r.ReadUInt32();
                int blockLength = r.ReadInt32();
                if (blockLength < 0 || blockLength > MaxProtectedPayload || blockLength > ms.Length - ms.Position)
                    throw new InvalidDataException("world.info protected block length is invalid.");
                byte[] protectedBlock = ReadExactly(r, blockLength);

                byte[] payload;
                using (MemoryStream bs = new MemoryStream(protectedBlock, false))
                using (BinaryReader br = new BinaryReader(bs))
                {
                    int hashLength = br.ReadInt32();
                    if (hashLength != 16) throw new InvalidDataException("world.info MD5 length is invalid.");
                    byte[] expectedHash = ReadExactly(br, hashLength);
                    int encryptedLength = br.ReadInt32();
                    if (encryptedLength < 0 || encryptedLength > MaxProtectedPayload || encryptedLength > bs.Length - bs.Position)
                        throw new InvalidDataException("world.info encrypted payload length is invalid.");
                    byte[] encrypted = ReadExactly(br, encryptedLength);
                    byte[] actualHash;
                    using (MD5 md5 = MD5.Create()) actualHash = md5.ComputeHash(encrypted);
                    if (!ConstantEquals(expectedHash, actualHash))
                        throw new InvalidDataException("world.info integrity hash does not match.");
                    payload = (flags & 2) != 0 ? DecryptPayload(encrypted, profileId) : encrypted;
                }

                if ((flags & 1) != 0)
                    payload = DecompressPayload(payload);
                if (payload.Length > MaxProtectedPayload)
                    throw new InvalidDataException("world.info exceeds the supported protected-save size.");
                return payload;
            }
        }

        public static WorldInfo ReadWorldInfo(string path, string profileId)
        {
            return ParseWorldInfo(UnprotectSave(File.ReadAllBytes(path), profileId));
        }

        public static void ValidateWorldInfoFile(string path, string profileId, WorldInfo expected)
        {
            if (!File.Exists(path)) throw new FileNotFoundException("Staged world.info is missing.", path);
            WorldInfo actual = ReadWorldInfo(path, profileId);
            if (actual.Version != WorldBuilderInfo.WorldInfoVersion || actual.TerrainVersion != WorldBuilderInfo.TerrainVersion)
                throw new InvalidDataException("Staged world.info has an unexpected format version.");
            if (expected != null)
            {
                if (actual.WorldID != expected.WorldID) throw new InvalidDataException("Staged world ID changed unexpectedly.");
                if (!string.Equals(actual.Name, expected.Name, StringComparison.Ordinal)) throw new InvalidDataException("Staged world name did not read back correctly.");
                if (actual.Seed != expected.Seed) throw new InvalidDataException("Staged world seed did not read back correctly.");
                if (!string.Equals(actual.OwnerGamerTag, expected.OwnerGamerTag, StringComparison.Ordinal)) throw new InvalidDataException("Staged world owner did not read back correctly.");
            }
        }

        public static int ParseSeed(string text, out bool generated)
        {
            string value = (text ?? "").Trim();
            if (value.Length == 0)
            {
                generated = true;
                lock (SeedSync) return SeedRandom.Next();
            }

            generated = false;
            int seed;
            if (!int.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out seed) || seed < 0 || seed > 2147483646)
                throw new FormatException("Seed must be blank or a whole number from 0 through 2,147,483,646.");
            return seed;
        }

        // CastleMiner Z creates a fresh System.Random for each normal new-world seed
        // and immediately calls Next(). Keep this separate from generic/custom scenario
        // seed handling so the stock Normal World path mirrors the game exactly.
        public static int ParseOfficialNormalSeed(string text, out bool generated)
        {
            string value = (text ?? "").Trim();
            if (value.Length == 0)
            {
                generated = true;
                return new Random().Next();
            }

            generated = false;
            int seed;
            if (!int.TryParse(value, NumberStyles.None, CultureInfo.InvariantCulture, out seed) || seed < 0 || seed > 2147483646)
                throw new FormatException("Seed must be blank or a whole number from 0 through 2,147,483,646.");
            return seed;
        }

        public static long DotNetTicks(DateTime value)
        {
            return value.Ticks;
        }

        // CastleMiner Z 1.9.9.8 WorldInfo.MakeNew(null, seed) uses the English
        // Strings.New_World resource followed by DateTime.Now.ToString("g").
        // Normal World generation intentionally mirrors that behavior instead of
        // exposing a custom-name convenience that the game itself does not use.
        public static string BuildOfficialNormalWorldName(DateTime localTime)
        {
            return "New World " + localTime.ToString("g", CultureInfo.CurrentCulture);
        }

        public static void ValidateProfileId(string profileId)
        {
            if (string.IsNullOrWhiteSpace(profileId) || profileId.Any(c => c < '0' || c > '9'))
                throw new ArgumentException("Steam profile ID must contain digits only.");
            ulong ignored;
            if (!ulong.TryParse(profileId, NumberStyles.None, CultureInfo.InvariantCulture, out ignored))
                throw new ArgumentException("Steam profile ID is not a valid numeric profile identifier.");
        }

        private static byte[] CompressPayload(byte[] raw)
        {
            using (MemoryStream plain = new MemoryStream())
            {
                using (BinaryWriter w = new BinaryWriter(plain, Encoding.UTF8, true))
                {
                    w.Write(raw.Length);
                    w.Write(raw);
                }
                plain.Position = 0;
                using (MemoryStream compressed = new MemoryStream())
                {
                    using (DeflateStream deflate = new DeflateStream(compressed, CompressionMode.Compress, true))
                        plain.CopyTo(deflate);
                    return compressed.ToArray();
                }
            }
        }

        private static byte[] DecompressPayload(byte[] compressed)
        {
            using (MemoryStream input = new MemoryStream(compressed, false))
            using (DeflateStream deflate = new DeflateStream(input, CompressionMode.Decompress))
            using (MemoryStream plain = new MemoryStream())
            {
                deflate.CopyTo(plain);
                byte[] withLength = plain.ToArray();
                using (BinaryReader r = new BinaryReader(new MemoryStream(withLength, false)))
                {
                    int length = r.ReadInt32();
                    if (length < 0 || length > MaxProtectedPayload || length > withLength.Length - 4)
                        throw new InvalidDataException("Decompressed world.info length is invalid.");
                    return ReadExactly(r, length);
                }
            }
        }

        private static byte[] EncryptPayload(byte[] payload, string profileId)
        {
            byte[] block;
            using (MemoryStream ms = new MemoryStream())
            using (BinaryWriter w = new BinaryWriter(ms))
            {
                w.Write(payload.Length);
                w.Write(payload);
                w.Flush();
                int padded = ((int)ms.Length + 15) / 16 * 16;
                block = new byte[padded];
                Buffer.BlockCopy(ms.ToArray(), 0, block, 0, (int)ms.Length);
            }
            using (Aes aes = Aes.Create())
            {
                aes.Key = DeriveKey(profileId);
                aes.Mode = CipherMode.ECB;
                aes.Padding = PaddingMode.None;
                using (ICryptoTransform transform = aes.CreateEncryptor())
                    return transform.TransformFinalBlock(block, 0, block.Length);
            }
        }

        private static byte[] DecryptPayload(byte[] encrypted, string profileId)
        {
            if (encrypted.Length == 0 || encrypted.Length % 16 != 0)
                throw new InvalidDataException("Encrypted world.info payload is not block-aligned.");
            byte[] block;
            using (Aes aes = Aes.Create())
            {
                aes.Key = DeriveKey(profileId);
                aes.Mode = CipherMode.ECB;
                aes.Padding = PaddingMode.None;
                using (ICryptoTransform transform = aes.CreateDecryptor())
                    block = transform.TransformFinalBlock(encrypted, 0, encrypted.Length);
            }
            using (BinaryReader r = new BinaryReader(new MemoryStream(block, false)))
            {
                int length = r.ReadInt32();
                if (length < 0 || length > MaxProtectedPayload || length > block.Length - 4)
                    throw new InvalidDataException("Decrypted world.info payload length is invalid.");
                return ReadExactly(r, length);
            }
        }

        private static byte[] DeriveKey(string profileId)
        {
            using (MD5 md5 = MD5.Create())
                return md5.ComputeHash(Encoding.UTF8.GetBytes(profileId + "CMZ778"));
        }

        private static int ReadWorldObjectCount(BinaryReader r, string label, int minimumRecordBytes)
        {
            int count = r.ReadInt32();
            if (count < 0) throw new InvalidDataException("world.info " + label + " count is negative.");
            long remaining = r.BaseStream.Length - r.BaseStream.Position;
            if (minimumRecordBytes > 0 && count > remaining / minimumRecordBytes)
                throw new InvalidDataException("world.info " + label + " count exceeds the remaining payload.");
            return count;
        }

        private static void SkipIntVector3(BinaryReader r)
        {
            r.ReadInt32();
            r.ReadInt32();
            r.ReadInt32();
        }

        private static void SkipCrateRecord(BinaryReader r)
        {
            // DNA.CastleMinerZ.Inventory.Crate.Write:
            // IntVector3 location + 32 inventory slots. Each slot writes a Boolean;
            // occupied slots then write Int16 item class, Int16 stack count, Single health.
            SkipIntVector3(r);
            for (int slot = 0; slot < 32; slot++)
            {
                if (!r.ReadBoolean()) continue;
                r.ReadInt16();
                r.ReadInt16();
                r.ReadSingle();
            }
        }

        private static void SkipDoorRecord(BinaryReader r)
        {
            // Door.Write: IntVector3 location + one model byte.
            SkipIntVector3(r);
            r.ReadByte();
        }

        private static void SkipSpawnerRecord(BinaryReader r)
        {
            // Spawner.Write: IntVector3 location + current spawn ID string.
            SkipIntVector3(r);
            ReadDotNetString(r);
        }

        private static void WriteDotNetString(BinaryWriter w, string value)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(value ?? "");
            Write7BitEncodedInt(w, bytes.Length);
            w.Write(bytes);
        }

        private static string ReadDotNetString(BinaryReader r)
        {
            int length = Read7BitEncodedInt(r);
            if (length < 0 || length > 1024 * 1024) throw new InvalidDataException("world.info string length is invalid.");
            return Encoding.UTF8.GetString(ReadExactly(r, length));
        }

        private static void Write7BitEncodedInt(BinaryWriter w, int value)
        {
            uint v = (uint)value;
            while (v >= 0x80)
            {
                w.Write((byte)(v | 0x80));
                v >>= 7;
            }
            w.Write((byte)v);
        }

        private static int Read7BitEncodedInt(BinaryReader r)
        {
            int count = 0;
            int shift = 0;
            while (shift != 35)
            {
                byte b = r.ReadByte();
                count |= (b & 0x7F) << shift;
                shift += 7;
                if ((b & 0x80) == 0) return count;
            }
            throw new FormatException("Invalid 7-bit encoded integer.");
        }

        private static byte[] ReadExactly(BinaryReader r, int count)
        {
            byte[] data = r.ReadBytes(count);
            if (data.Length != count) throw new EndOfStreamException();
            return data;
        }

        private static bool ConstantEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++) diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }

    public sealed class WorldProfileService
    {
        private readonly string _gameExePath;

        public WorldProfileService(string gameExePath)
        {
            _gameExePath = gameExePath;
        }

        public static string ResolveCastleMinerZRoot()
        {
            string overrideRoot = Environment.GetEnvironmentVariable("CMZWB_CMZ_ROOT");
            if (!string.IsNullOrWhiteSpace(overrideRoot)) return Path.GetFullPath(overrideRoot);
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "CastleMinerZ");
        }

        public string CastleMinerZRoot
        {
            get { return ResolveCastleMinerZRoot(); }
        }

        public List<SteamProfile> DiscoverProfiles()
        {
            List<SteamProfile> result = new List<SteamProfile>();
            string root = CastleMinerZRoot;
            if (!Directory.Exists(root)) return result;
            foreach (string dir in Directory.GetDirectories(root))
            {
                string id = Path.GetFileName(dir);
                try { WorldFormat.ValidateProfileId(id); }
                catch { continue; }
                string worlds = Path.Combine(dir, "Worlds");
                string persona = ResolveSteamPersonaName(_gameExePath, id);
                string fromWorld = Directory.Exists(worlds) ? DetectOwner(id, worlds) : null;
                int existingCount = Directory.Exists(worlds)
                    ? Directory.GetDirectories(worlds).Count(x => !Path.GetFileName(x).StartsWith(".cmzwb-stage-", StringComparison.OrdinalIgnoreCase))
                    : 0;
                SteamProfile profile = new SteamProfile {
                    ProfileId = id,
                    WorldsDirectory = worlds,
                    OwnerGamerTag = !string.IsNullOrWhiteSpace(persona) ? persona : fromWorld,
                    ExistingWorldCount = existingCount
                };
                result.Add(profile);
            }
            return result.OrderByDescending(x => x.ExistingWorldCount).ThenBy(x => x.ProfileId).ToList();
        }

        public static string ResolveSteamPersonaName(string gameExePath, string profileId)
        {
            WorldFormat.ValidateProfileId(profileId);
            foreach (string root in CandidateSteamRoots(gameExePath))
            {
                try
                {
                    string vdf = Path.Combine(root, "config", "loginusers.vdf");
                    string name = ParsePersonaName(File.Exists(vdf) ? File.ReadAllText(vdf) : null, profileId);
                    if (!string.IsNullOrWhiteSpace(name)) return name;
                }
                catch { }
            }
            return null;
        }

        public static string ParsePersonaName(string vdfText, string profileId)
        {
            if (string.IsNullOrWhiteSpace(vdfText) || string.IsNullOrWhiteSpace(profileId)) return null;
            string currentId = null;
            int currentDepth = -1;
            int depth = 0;
            using (StringReader reader = new StringReader(vdfText))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    string t = line.Trim();
                    if (!string.IsNullOrWhiteSpace(currentId) && t.StartsWith("\"PersonaName\"", StringComparison.OrdinalIgnoreCase))
                    {
                        string[] pair = ParseVdfPair(t);
                        if (pair != null && string.Equals(pair[0], "PersonaName", StringComparison.OrdinalIgnoreCase))
                            return pair[1];
                    }
                    else if (t.StartsWith("\"") && t.EndsWith("\"", StringComparison.Ordinal) && t.Length >= 2 && t.IndexOf('"', 1) == t.Length - 1)
                    {
                        string keyOnly = UnquoteVdf(t);
                        if (string.Equals(keyOnly, profileId, StringComparison.Ordinal))
                        {
                            currentId = keyOnly;
                            currentDepth = depth;
                        }
                    }

                    for (int i = 0; i < t.Length; i++)
                    {
                        if (t[i] == '{') depth++;
                        else if (t[i] == '}')
                        {
                            depth--;
                            if (currentId != null && depth <= currentDepth)
                            {
                                currentId = null;
                                currentDepth = -1;
                            }
                        }
                    }
                }
            }
            return null;
        }

        private static IEnumerable<string> CandidateSteamRoots(string gameExePath)
        {
            HashSet<string> roots = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                DirectoryInfo current = !string.IsNullOrWhiteSpace(gameExePath)
                    ? new DirectoryInfo(Path.GetDirectoryName(Path.GetFullPath(gameExePath)))
                    : null;
                while (current != null)
                {
                    if (string.Equals(current.Name, "steamapps", StringComparison.OrdinalIgnoreCase) && current.Parent != null)
                    {
                        roots.Add(current.Parent.FullName);
                        break;
                    }
                    current = current.Parent;
                }
            }
            catch { }

            foreach (RegistryView view in new [] { RegistryView.Registry64, RegistryView.Registry32 })
            {
                try
                {
                    using (RegistryKey baseKey = RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, view))
                    using (RegistryKey key = baseKey.OpenSubKey(@"Software\Valve\Steam"))
                    {
                        object value = key == null ? null : key.GetValue("SteamPath");
                        if (value != null && Directory.Exists(Convert.ToString(value))) roots.Add(Path.GetFullPath(Convert.ToString(value)));
                    }
                }
                catch { }
            }
            return roots;
        }

        private static string[] ParseVdfPair(string line)
        {
            List<string> values = new List<string>();
            int i = 0;
            while (i < line.Length && values.Count < 2)
            {
                while (i < line.Length && line[i] != '"') i++;
                if (i >= line.Length) break;
                int start = ++i;
                StringBuilder b = new StringBuilder();
                bool escaped = false;
                for (; i < line.Length; i++)
                {
                    char c = line[i];
                    if (escaped) { b.Append(c); escaped = false; continue; }
                    if (c == '\\') { escaped = true; continue; }
                    if (c == '"') break;
                    b.Append(c);
                }
                values.Add(b.ToString());
                i++;
            }
            return values.Count == 2 ? values.ToArray() : null;
        }

        private static string UnquoteVdf(string value)
        {
            string[] pair = ParseVdfPair(value + " \"\"");
            return pair == null ? null : pair[0];
        }

        private static string DetectOwner(string profileId, string worlds)
        {
            IEnumerable<string> infos;
            try
            {
                infos = Directory.GetDirectories(worlds)
                    .Where(x => !Path.GetFileName(x).StartsWith(".cmzwb-stage-", StringComparison.OrdinalIgnoreCase))
                    .Select(x => Path.Combine(x, "world.info"))
                    .Where(File.Exists)
                    .OrderByDescending(File.GetLastWriteTimeUtc);
            }
            catch { return null; }

            foreach (string path in infos.Take(40))
            {
                try
                {
                    WorldInfo info = WorldFormat.ReadWorldInfo(path, profileId);
                    if (!string.IsNullOrWhiteSpace(info.OwnerGamerTag)) return info.OwnerGamerTag;
                    if (!string.IsNullOrWhiteSpace(info.CreatorGamerTag)) return info.CreatorGamerTag;
                }
                catch { }
            }
            return null;
        }
    }

    public sealed class WorldCreationService
    {
        // Custom/scenario staging path. This intentionally retains explicit metadata
        // because custom scenarios are not the stock Normal World creation workflow.
        public StagedWorld Prepare(string profileId, string owner, string worldName, int seed)
        {
            return PrepareCore(profileId, owner, worldName, seed);
        }

        // Exact Normal World path for CastleMiner Z 1.9.9.8. The stock game creates
        // the world with a null creator (which auto-names it), then TakeOwnership
        // assigns creator/owner and regenerates WorldID before saving. Random/discarded
        // GUIDs are deliberately consumed in the same conceptual order where practical.
        public StagedWorld PrepareOfficialNormal(string profileId, string owner, int seed)
        {
            WorldFormat.ValidateProfileId(profileId);
            owner = (owner ?? "").Trim();
            if (owner.Length == 0)
                throw new ArgumentException("The selected Steam profile does not have a resolvable player name. Open CastleMiner Z through Steam once, then refresh profiles.");
            if (seed < 0 || seed > 2147483646) throw new ArgumentOutOfRangeException("seed");

            // WorldInfo() creates a save path, and MakeNew() creates another one. The
            // first path is discarded by the stock code. Consume the corresponding GUID
            // so the implementation follows the same lifecycle without persisting it.
            Guid.NewGuid();
            Guid folderId = Guid.NewGuid();
            string folderText = folderId.ToString().ToLowerInvariant();

            DateTime nameTime = DateTime.Now;
            string worldName = WorldFormat.BuildOfficialNormalWorldName(nameTime);
            DateTime createdTime = DateTime.Now;

            // MakeNew assigns an initial WorldID; WorldManager.TakeOwnership replaces it.
            Guid.NewGuid();
            Guid worldId = Guid.NewGuid();

            WorldInfo info = new WorldInfo {
                Version = WorldBuilderInfo.WorldInfoVersion,
                TerrainVersion = WorldBuilderInfo.TerrainVersion,
                Name = worldName,
                OwnerGamerTag = owner,
                CreatorGamerTag = owner,
                CreatedTicks = WorldFormat.DotNetTicks(createdTime),
                LastPlayedTicks = WorldFormat.DotNetTicks(createdTime),
                Seed = seed,
                WorldID = worldId,
                LastX = 8.0f,
                LastY = 128.0f,
                LastZ = -8.0f,
                InfiniteResource = false,
                ServerMessage = owner + "'s Server",
                ServerPassword = "",
                HellBosses = 0,
                MaxHellBosses = 0
            };

            string worldsRoot = Path.Combine(WorldProfileService.ResolveCastleMinerZRoot(), profileId, "Worlds");
            Directory.CreateDirectory(worldsRoot);
            string stage = Path.Combine(worldsRoot, ".cmzwb-stage-" + folderText);
            string final = Path.Combine(worldsRoot, folderText);
            if (Directory.Exists(stage) || Directory.Exists(final))
                throw new IOException("A generated world folder already exists. No files were overwritten.");

            Directory.CreateDirectory(stage);
            try
            {
                byte[] raw = WorldFormat.SerializeWorldInfo(info);
                byte[] protectedBytes = WorldFormat.ProtectSave(raw, profileId);
                string infoPath = Path.Combine(stage, "world.info");
                File.WriteAllBytes(infoPath, protectedBytes);
                WorldFormat.ValidateWorldInfoFile(infoPath, profileId, info);

                if (Directory.GetFiles(stage, "*.dat", SearchOption.TopDirectoryOnly).Length != 0)
                    throw new InvalidDataException("Normal World creation unexpectedly pre-generated terrain data. Stock CMZ leaves terrain generation to the game on load.");
                if (Directory.GetFiles(stage, "*.inv", SearchOption.TopDirectoryOnly).Length != 0)
                    throw new InvalidDataException("Normal World creation unexpectedly pre-generated player inventory. Stock CMZ creates mode-specific player inventory after the world session begins.");
            }
            catch
            {
                try { Directory.Delete(stage, true); } catch { }
                throw;
            }

            return new StagedWorld {
                ProfileID = profileId,
                Owner = owner,
                WorldName = worldName,
                Seed = seed,
                WorldID = worldId,
                FolderID = folderId,
                StagePath = stage,
                FinalPath = final,
                CreatedAt = createdTime,
                Info = info
            };
        }

        // Scenario packages may request an official CMZ Normal World foundation while
        // still presenting a scenario-specific world name. Build the official-normal
        // baseline first, then treat the custom name as the scenario's first metadata
        // change. Terrain generation remains entirely game-owned from the same seed.
        public StagedWorld PrepareOfficialNormalForScenario(string profileId, string owner, string worldName, int seed)
        {
            worldName = (worldName ?? "").Trim();
            if (worldName.Length == 0) throw new ArgumentException("World name is required.");
            if (worldName.Length > 128) throw new ArgumentException("World name must be 128 characters or fewer.");

            StagedWorld stage = PrepareOfficialNormal(profileId, owner, seed);
            try
            {
                stage.Info.Name = worldName;
                stage.WorldName = worldName;
                string infoPath = Path.Combine(stage.StagePath, "world.info");
                byte[] raw = WorldFormat.SerializeWorldInfo(stage.Info);
                File.WriteAllBytes(infoPath, WorldFormat.ProtectSave(raw, profileId));
                WorldFormat.ValidateWorldInfoFile(infoPath, profileId, stage.Info);
                return stage;
            }
            catch
            {
                stage.Dispose();
                throw;
            }
        }

        private StagedWorld PrepareCore(string profileId, string owner, string worldName, int seed)
        {
            WorldFormat.ValidateProfileId(profileId);
            owner = (owner ?? "").Trim();
            worldName = (worldName ?? "").Trim();
            if (owner.Length == 0) throw new ArgumentException("Owner / creator name is required.");
            if (worldName.Length == 0) throw new ArgumentException("World name is required.");
            if (worldName.Length > 128) throw new ArgumentException("World name must be 128 characters or fewer.");
            if (seed < 0 || seed > 2147483646) throw new ArgumentOutOfRangeException("seed");

            string worldsRoot = Path.Combine(WorldProfileService.ResolveCastleMinerZRoot(), profileId, "Worlds");
            Directory.CreateDirectory(worldsRoot);

            Guid worldId = Guid.NewGuid();
            Guid folderId = Guid.NewGuid();
            string folderText = folderId.ToString().ToLowerInvariant();
            string stage = Path.Combine(worldsRoot, ".cmzwb-stage-" + folderText);
            string final = Path.Combine(worldsRoot, folderText);
            if (Directory.Exists(stage) || Directory.Exists(final))
                throw new IOException("A generated world folder already exists. No files were overwritten.");

            DateTime now = DateTime.Now;
            long ticks = WorldFormat.DotNetTicks(now);
            WorldInfo info = new WorldInfo {
                Version = WorldBuilderInfo.WorldInfoVersion,
                TerrainVersion = WorldBuilderInfo.TerrainVersion,
                Name = worldName,
                OwnerGamerTag = owner,
                CreatorGamerTag = owner,
                CreatedTicks = ticks,
                LastPlayedTicks = ticks,
                Seed = seed,
                WorldID = worldId,
                LastX = 8.0f,
                LastY = 128.0f,
                LastZ = -8.0f,
                InfiniteResource = false,
                ServerMessage = owner + "'s Server",
                ServerPassword = "",
                HellBosses = 0,
                MaxHellBosses = 0
            };

            Directory.CreateDirectory(stage);
            try
            {
                byte[] raw = WorldFormat.SerializeWorldInfo(info);
                byte[] protectedBytes = WorldFormat.ProtectSave(raw, profileId);
                string infoPath = Path.Combine(stage, "world.info");
                File.WriteAllBytes(infoPath, protectedBytes);
                WorldFormat.ValidateWorldInfoFile(infoPath, profileId, info);
            }
            catch
            {
                try { Directory.Delete(stage, true); } catch { }
                throw;
            }

            return new StagedWorld {
                ProfileID = profileId,
                Owner = owner,
                WorldName = worldName,
                Seed = seed,
                WorldID = worldId,
                FolderID = folderId,
                StagePath = stage,
                FinalPath = final,
                CreatedAt = now,
                Info = info
            };
        }

        public string CreateAndCommit(string profileId, string owner, string worldName, int seed)
        {
            using (StagedWorld stage = Prepare(profileId, owner, worldName, seed))
            {
                stage.Commit();
                return stage.FinalPath;
            }
        }

        public string CreateAndCommitOfficialNormal(string profileId, string owner, int seed, out string worldName)
        {
            using (StagedWorld stage = PrepareOfficialNormal(profileId, owner, seed))
            {
                worldName = stage.WorldName;
                stage.Commit();
                return stage.FinalPath;
            }
        }

        public static bool IsGameRunning()
        {
            try { return Process.GetProcessesByName("CastleMinerZ").Length > 0; }
            catch { return false; }
        }
    }
}
